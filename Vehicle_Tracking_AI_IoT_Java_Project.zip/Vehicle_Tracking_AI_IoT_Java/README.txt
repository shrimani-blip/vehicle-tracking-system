AI + IoT Vehicle Tracking System — Java
Requirements: JDK 17 or later.

Compile:
javac VehicleTrackingSystem.java

Run:
java VehicleTrackingSystem

Menu:
1. Track vehicle once
2. Run live tracking (5 updates)
3. View project information
4. Exit

Features: simulated GPS latitude/longitude, random speed, timestamp, overspeeding
alert (>80 km/h), geofence alert, NORMAL/ALERT status.

Important: educational prototype only. GPS/IoT telemetry is simulated; no physical
GPS, ESP32 or vehicle is connected. Detection is rule-based, not a trained AI model.
