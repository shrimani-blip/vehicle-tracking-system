import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

class Vehicle {
    private final String vehicleNumber;
    private double latitude, longitude;
    private int speed;
    private String timestamp, status;
    private final List<String> alerts = new ArrayList<>();

    Vehicle(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public void updateTelemetry(Random random) {
        latitude = 11.0168 + random.nextDouble() * 0.01;
        longitude = 76.9558 + random.nextDouble() * 0.01;
        speed = 30 + random.nextInt(71);
        timestamp = LocalDateTime.now().format(
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        detectEvents();
    }

    private void detectEvents() {
        alerts.clear();
        if (speed > 80) alerts.add("Overspeeding");
        if (latitude < 11.00 || latitude > 11.04 ||
            longitude < 76.94 || longitude > 77.00) {
            alerts.add("Geofence violation");
        }
        if (alerts.isEmpty()) {
            alerts.add("Normal");
            status = "NORMAL";
        } else {
            status = "ALERT";
        }
    }

    public void display() {
        System.out.println("\nVehicle Number : " + vehicleNumber);
        System.out.println("Timestamp      : " + timestamp);
        System.out.printf("Latitude       : %.6f%n", latitude);
        System.out.printf("Longitude      : %.6f%n", longitude);
        System.out.println("Speed          : " + speed + " km/h");
        System.out.println("Alerts         : " + String.join(", ", alerts));
        System.out.println("Status         : " + status);
    }
}

public class VehicleTrackingSystem {
    private static final Random RANDOM = new Random();

    private static void showMenu() {
        System.out.println("\n======================================");
        System.out.println(" AI + IoT VEHICLE TRACKING SYSTEM");
        System.out.println("======================================");
        System.out.println("1. Track vehicle once");
        System.out.println("2. Run live tracking (5 updates)");
        System.out.println("3. View project information");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    public static void main(String[] args) throws InterruptedException {
        Scanner scanner = new Scanner(System.in);
        Vehicle vehicle = new Vehicle("TN-38-AB-1234");
        boolean running = true;

        while (running) {
            showMenu();
            if (!scanner.hasNextInt()) {
                System.out.println("Please enter a number from 1 to 4.");
                scanner.nextLine();
                continue;
            }

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    vehicle.updateTelemetry(RANDOM);
                    vehicle.display();
                    break;
                case 2:
                    for (int i = 1; i <= 5; i++) {
                        System.out.println("\n--- Tracking Update " + i + " ---");
                        vehicle.updateTelemetry(RANDOM);
                        vehicle.display();
                        if (i < 5) Thread.sleep(1000);
                    }
                    break;
                case 3:
                    System.out.println("\nPROJECT: AI + IoT Based Vehicle Tracking System");
                    System.out.println("Purpose: Monitor simulated GPS and speed.");
                    System.out.println("IoT concept: GPS/ESP32 sends telemetry to an application.");
                    System.out.println("Detection: Rule-based overspeed and geofence alerts.");
                    System.out.println("Note: This version simulates data; no real hardware is connected.");
                    break;
                case 4:
                    running = false;
                    System.out.println("Thank you for using the Vehicle Tracking System.");
                    break;
                default:
                    System.out.println("Invalid choice. Enter 1, 2, 3 or 4.");
            }
        }
        scanner.close();
    }
}
